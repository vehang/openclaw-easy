/**
 * 全局配置文件
 */

// 获取环境变量，支持service worker环境
const ENV = (typeof window !== 'undefined' && window.ENV) || 'development';

// 环境配置
const envConfig = {
  development: {
    TARGET_WEBSITE_URL: 'http://localhost:3000',
    API_BASE_URL: 'http://localhost:8080'
  },
  test: {
    TARGET_WEBSITE_URL: 'http://192.168.1.123:3001',
    API_BASE_URL: 'http://192.168.1.123:48080'
  },
  production: {
    TARGET_WEBSITE_URL: 'https://www.baoboxs.com',
    API_BASE_URL: 'https://www.baoboxs.com'
  }
};

// 当前环境配置
const currentConfig = {
    TARGET_WEBSITE_URL: 'https://www.baoboxs.com',
    API_BASE_URL: 'https://www.baoboxs.com'
};

// 导出基础配置
export const TARGET_WEBSITE_URL = currentConfig.TARGET_WEBSITE_URL;
export const API_BASE_URL = currentConfig.API_BASE_URL;

// API 端点
export const API_ENDPOINTS = {
  UPLOAD_BOOKMARKS: '/api/helper/user/upload-bookmarks',
  ADD_BOOKMARK: '/api/helper/user/add-bookmark',
  COLLECT_BOOKMARK: '/api/helper/collect/add'
};

// 完整的API URL
export const UPLOAD_BOOKMARKS_API_URL = API_BASE_URL + API_ENDPOINTS.UPLOAD_BOOKMARKS;
export const ADD_BOOKMARK_API_URL = API_BASE_URL + API_ENDPOINTS.ADD_BOOKMARK;
export const COLL_BOOKMARK_API_URL = API_BASE_URL + API_ENDPOINTS.COLLECT_BOOKMARK;

// 存储键名配置
export const STORAGE_KEYS = {
  // 缓存数据键
  BBS_CACHE_DATA: 'bbsCacheData',
  USER_DATA: 'userData',
  DEVICE_ID: 'deviceId',
  LAST_UPDATED: 'lastUpdated',
  LAST_SYNCED_BOOKMARKS: 'lastSyncedBookmarks',
  LAST_SYNC_TIME: 'lastSyncTime',
  
  // 数据源信息键
  USER_DATA_SOURCE: 'userDataSource',
  DEVICE_ID_SOURCE: 'deviceIdSource'
};

// LocalStorage 中可能的用户信息键名
export const USER_INFO_KEYS = [
  'userData',
  'baoboxs_userData',
  'deviceId',
  'baoboxs_deviceId',
  'userInfo',
  'user',
  'token',
  'accessToken',
  'baoboxs_attr1',
  'baoboxs_attr2',
  'baoboxs_attr3',
  'baoboxs_attr4',
  'baoboxs_attr5'
];

// 设备ID可能的键名
export const DEVICE_ID_KEYS = [
  'deviceId',
  'device_id',
  'device-id',
  'baoboxDeviceId',
  'userDeviceId',
  'clientId',
  'client_id'
];

// 请求配置
export const REQUEST_CONFIG = {
  TIMEOUT: 10000, // 10秒超时
  RETRY_COUNT: 3,
  RETRY_DELAY: 1000 // 1秒重试延迟
};

// 响应状态码
export const RESPONSE_CODES = {
  SUCCESS: 0,
  AUTH_EXPIRED: 9996
};

// UI 配置
export const UI_CONFIG = {
  STATUS_MESSAGE_DISPLAY_TIME: 3000,
  BOOKMARK_TITLE_MAX_LENGTH: 40,
  FOLDER_INDENT_SIZE: 15
};

// 其他全局配置...
// 只在有console的环境中打印日志
if (typeof console !== 'undefined') {
  console.log(`当前环境: ${ENV}, API地址: ${API_BASE_URL}`);
}