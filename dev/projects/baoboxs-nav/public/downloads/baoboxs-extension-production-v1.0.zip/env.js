// 正式环境配置
window.ENV = 'production'; 