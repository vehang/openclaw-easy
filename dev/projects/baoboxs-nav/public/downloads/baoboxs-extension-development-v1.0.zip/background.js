/**
 * 背景脚本 - 浏览器插件的核心服务
 * 负责处理书签同步、用户数据管理、右键菜单等功能
 */

import {TARGET_WEBSITE_URL, STORAGE_KEYS, RESPONSE_CODES} from './config.js';
import {getCacheData, isUserLoggedIn, openLoginPage, clearUserCache} from './userDataService.js';
import {uploadBookmarks, addBookmark} from './apiService.js';
import {formatDate, getBrowserName, logWithTimestamp, deepClone, buildResponse} from './utils.js';

/**
 * 扩展安装时的初始化
 */
chrome.runtime.onInstalled.addListener(async () => {
    logWithTimestamp('info', '浏览器插件已安装');

    // 创建右键菜单
    try {
        chrome.contextMenus.create({
            id: "saveToBookmarks", title: "收藏到程序员宝盒", contexts: ["page", "link"]
        });
        logWithTimestamp('info', '右键菜单已创建');
    } catch (error) {
        logWithTimestamp('error', '创建右键菜单失败', error.message);
    }
});

/**
 * 获取浏览器收藏夹数据
 * @returns {Promise<Array>} 书签树数组
 */
async function getBookmarks() {
    return new Promise((resolve, reject) => {
        chrome.bookmarks.getTree((bookmarksTree) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve(bookmarksTree);
            }
        });
    });
}

/**
 * 处理从内容脚本获取的网站数据
 * @param {Object} data 网站数据
 * @returns {Promise<Object>} 处理结果
 */
async function handleWebsiteData(data) {
    if (!data) {
        return buildResponse(false, null, '无数据可处理');
    }

    try {
        const updates = {};

        // 存储设备ID
        if (data.deviceId && data.deviceId.value) {
            updates[STORAGE_KEYS.DEVICE_ID] = data.deviceId.value;
            updates[STORAGE_KEYS.DEVICE_ID_SOURCE] = {
                key: data.deviceId.key, website: TARGET_WEBSITE_URL, timestamp: new Date().toISOString()
            };
            logWithTimestamp('info', '已保存设备ID', data.deviceId.value);
        }

        // 存储用户数据
        if (data.userData && data.userData.value) {
            updates[STORAGE_KEYS.USER_DATA] = data.userData.value;
            logWithTimestamp('info', '已保存用户数据');
        }

        if (Object.keys(updates).length > 0) {
            await chrome.storage.local.set(updates);
        }

        return buildResponse(true, updates);
    } catch (error) {
        logWithTimestamp('error', '保存网站数据失败', error.message);
        return buildResponse(false, null, error.message);
    }
}

/**
 * 检查书签是否发生变化
 * @param {Array} newBookmarks 新的书签数据
 * @returns {Promise<boolean>} 是否发生变化
 */
async function hasBookmarksChanged(newBookmarks) {
    try {
        const result = await chrome.storage.local.get(STORAGE_KEYS.LAST_SYNCED_BOOKMARKS);
        const previousBookmarksJson = JSON.stringify(result[STORAGE_KEYS.LAST_SYNCED_BOOKMARKS]);
        const newBookmarksJson = JSON.stringify(newBookmarks);

        return previousBookmarksJson !== newBookmarksJson;
    } catch (error) {
        logWithTimestamp('warn', '检查书签变化失败', error.message);
        return true; // 如果检查失败，默认认为有变化
    }
}

/**
 * 同步所有数据的主函数
 * @returns {Promise<Object>} 同步结果
 */
async function syncAllData() {
    try {
        logWithTimestamp('info', '开始同步数据');

        // 获取书签数据
        const bookmarks = await getBookmarks();
        logWithTimestamp('info', '已获取书签数据');

        // 检查书签是否有变化
        const hasChanged = await hasBookmarksChanged(bookmarks);
        if (!hasChanged) {
            logWithTimestamp('info', '书签未发生变化，跳过同步');
            return buildResponse(false, {code: 0, errorMsg: '上次同步成功后，书签未发生变化'});
        }

        // 获取缓存数据
        const cacheData = await getCacheData();
        if (!cacheData || !cacheData.userData) {
            throw new Error('无法获取用户数据');
        }

        // 构建同步数据
        const syncData = {
            bookmarks, timestamp: formatDate(new Date()), browserName: getBrowserName()
        };

        // 上传到服务器
        const result = await uploadBookmarks(syncData);

        // 如果成功，缓存书签数据
        if (result.success && result.data && result.data.code === RESPONSE_CODES.SUCCESS) {
            await chrome.storage.local.set({
                [STORAGE_KEYS.LAST_SYNCED_BOOKMARKS]: bookmarks
            });
            logWithTimestamp('info', '已缓存最新书签数据');
        }

        return result;
    } catch (error) {
        logWithTimestamp('error', '同步数据失败', error.message);
        return buildResponse(false, null, error.message);
    }
}

/**
 * 检查URL是否为受保护的页面
 * @param {string} url 页面URL
 * @returns {boolean} 是否为受保护页面
 */
function isProtectedUrl(url) {
    if (!url) return true;
    
    const protectedProtocols = [
        'chrome://',
        'chrome-extension://',
        'edge://',
        'moz-extension://',
        'about:',
        'data:',
        'javascript:',
        'file://'
    ];
    
    return protectedProtocols.some(protocol => url.startsWith(protocol));
}

/**
 * 获取网页元数据
 * @param {number} tabId 标签页ID
 * @returns {Promise<Object>} 页面元数据
 */
async function getPageMetadata(tabId) {
    try {
        // 首先获取标签页信息检查URL
        const tab = await chrome.tabs.get(tabId);
        
        // 如果是受保护的URL，直接返回空元数据
        if (isProtectedUrl(tab.url)) {
            logWithTimestamp('info', `跳过受保护页面的元数据获取: ${tab.url}`);
            return {description: '', keywords: ''};
        }
        
        const result = await chrome.scripting.executeScript({
            target: {tabId}, function: extractPageMetadata
        });

        return result[0]?.result || {description: '', keywords: ''};
    } catch (error) {
        logWithTimestamp('error', '获取页面元数据失败', error.message);
        return {description: '', keywords: ''};
    }
}

/**
 * 提取页面元数据的函数（在目标页面中执行）
 * @returns {Object} 页面元数据
 */
function extractPageMetadata() {
    const metadata = {
        description: '', keywords: ''
    };

    // 获取描述的选择器
    const descriptionSelectors = ['meta[name="description"]', 'meta[property="og:description"]', 'meta[property="twitter:description"]', 'meta[itemprop="description"]'];

    // 获取关键词的选择器
    const keywordsSelectors = ['meta[name="keywords"]', 'meta[property="article:tag"]', 'meta[property="og:keywords"]'];

    // 查找描述
    for (const selector of descriptionSelectors) {
        const meta = document.querySelector(selector);
        if (meta && meta.getAttribute('content')) {
            metadata.description = meta.getAttribute('content');
            break;
        }
    }

    // 查找关键词
    for (const selector of keywordsSelectors) {
        const meta = document.querySelector(selector);
        if (meta && meta.getAttribute('content')) {
            metadata.keywords = meta.getAttribute('content');
            break;
        }
    }

    // 如果还没找到，遍历所有meta标签
    if (!metadata.description || !metadata.keywords) {
        const allMetas = document.getElementsByTagName('meta');
        for (const meta of allMetas) {
            const name = meta.getAttribute('name');
            const content = meta.getAttribute('content');

            if (!metadata.description && name && name.toLowerCase() === 'description') {
                metadata.description = content;
            }

            if (!metadata.keywords && name && name.toLowerCase() === 'keywords') {
                metadata.keywords = content;
            }
        }
    }

    return metadata;
}

/**
 * 处理保存书签请求
 * @param {Object} pageInfo 页面信息
 * @returns {Promise<Object>} 保存结果
 */
async function handleSaveBookmark(pageInfo) {
    try {
        logWithTimestamp('info', '开始保存书签', pageInfo.title);
        logWithTimestamp('info', '页面信息详情', pageInfo);

        const bookmarkInfo = {
            url: pageInfo.url,
            title: pageInfo.title,
            favicon: pageInfo.favicon,
            timestamp: pageInfo.timestamp || formatDate(new Date()),
            description: pageInfo.description || '',
            keywords: pageInfo.keywords || ''
        };

        logWithTimestamp('info', '准备发送的书签数据', bookmarkInfo);

        const result = await addBookmark(bookmarkInfo);

        logWithTimestamp('info', '收藏请求结果', result);

        return result;
    } catch (error) {
        logWithTimestamp('error', '保存书签失败', error.message);
        return buildResponse(false, null, error.message);
    }
}

/**
 * 消息监听器 - 处理来自其他组件的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const {action} = message;

    // 异步处理函数
    const handleAsync = async (handler) => {
        try {
            const result = await handler();
            sendResponse(result);
        } catch (error) {
            logWithTimestamp('error', `处理消息失败: ${action}`, error.message);
            sendResponse(buildResponse(false, null, error.message));
        }
    };

    switch (action) {
        case 'storeWebsiteData':
            handleAsync(() => handleWebsiteData(message.data));
            return true;

        case 'getUserData':
            handleAsync(() => getCacheData());
            return true;

        case 'openLoginPage':
            handleAsync(() => openLoginPage());
            return true;

        case 'syncData':
            handleAsync(async () => {
                const isLoggedIn = await isUserLoggedIn();
                if (!isLoggedIn) {
                    await openLoginPage();
                    return buildResponse(false, null, '请先登录网站后再同步数据', {needLogin: true});
                }
                return await syncAllData();
            });
            return true;

        case 'saveBookmark':
            handleAsync(() => handleSaveBookmark(message.data));
            return true;

        default:
            logWithTimestamp('warn', `未知的消息类型: ${action}`);
            sendResponse(buildResponse(false, null, `未知的操作: ${action}`));
            return false;
    }
});

/**
 * 右键菜单点击事件处理
 */
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "saveToBookmarks") {
        try {
            // 获取页面元数据
            const metadata = await getPageMetadata(tab.id);
            logWithTimestamp('info', '获取到的元数据', metadata);

            const pageInfo = {
                url: info.linkUrl || tab.url,
                title: tab.title,
                favicon: `chrome://favicon/${tab.url}`,
                timestamp: formatDate(new Date()), ...metadata
            };

            const result = await handleSaveBookmark(pageInfo);

            if (result.success) {
                logWithTimestamp('info', '右键菜单收藏成功', pageInfo.title);
            } else {
                logWithTimestamp('error', '右键菜单收藏失败', result.error);
            }
        } catch (error) {
            logWithTimestamp('error', '右键菜单收藏出错', error.message);
        }
    }
});
