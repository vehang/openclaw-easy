/**
 * 用户数据服务
 * 负责用户数据的获取、保存、验证等操作
 */

import {TARGET_WEBSITE_URL, STORAGE_KEYS, USER_INFO_KEYS} from './config.js';
import {validateUserData, logWithTimestamp, withRetry, safeJsonParse, buildResponse} from './utils.js';

/**
 * 获取本地存储的用户数据
 * @returns {Promise<Object|null>} 用户缓存数据或null
 */
export async function getCacheData() {
    try {
        // 首先尝试从插件缓存中获取数据
        const bbsCacheData = await getFromPluginStorage(STORAGE_KEYS.BBS_CACHE_DATA);

        // 尝试从网站获取最新数据
        const webData = await getDataFromWebsite();

        if (webData) {
            // 缓存最新数据到插件中
            await cacheDataToPlugin(webData);
            return webData;
        }

        // 如果从网页获取失败，使用插件缓存的数据
        if (bbsCacheData) {
            logWithTimestamp('info', '从网页获取数据失败，使用插件缓存的数据');
            return bbsCacheData;
        }

        return null;
    } catch (error) {
        logWithTimestamp('error', '获取缓存数据失败', error.message);
        return null;
    }
}

/**
 * 从网站获取用户数据
 * @returns {Promise<Object|null>} 网站数据或null
 */
async function getDataFromWebsite() {
    try {
        // 查找现有的目标网站标签页
        const existingTabs = await chrome.tabs.query({url: `${TARGET_WEBSITE_URL}/*`});
        logWithTimestamp('info', `找到的目标网站标签页数量: ${existingTabs.length}`);

        if (existingTabs && existingTabs.length > 0) {
            logWithTimestamp('info', `使用现有标签页获取用户数据, tabId: ${existingTabs[0].id}`);
            const result = await executeDataExtractionScript(existingTabs[0].id);
            if (result) {
                return result;
            }
        }

        // 如果没有找到现有标签页或数据获取失败，创建新标签页
        return await createTabAndGetData();
    } catch (error) {
        logWithTimestamp('warn', '从网站获取用户数据失败', error.message);
        return null;
    }
}

/**
 * 创建新标签页并获取数据
 * @returns {Promise<Object|null>} 获取的数据或null
 */
async function createTabAndGetData() {
    try {
        const newTab = await chrome.tabs.create({url: TARGET_WEBSITE_URL, active: true});

        // 等待页面加载完成
        await waitForTabToLoad(newTab.id);

        const result = await executeDataExtractionScript(newTab.id);
        return result;
    } catch (error) {
        logWithTimestamp('warn', '打开目标网站并获取用户数据失败', error.message);
        return null;
    }
}

/**
 * 等待标签页加载完成
 * @param {number} tabId 标签页ID
 * @returns {Promise<void>}
 */
function waitForTabToLoad(tabId) {
    return new Promise((resolve) => {
        const checkLoaded = (updateTabId, changeInfo) => {
            if (updateTabId === tabId && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(checkLoaded);
                resolve();
            }
        };

        chrome.tabs.onUpdated.addListener(checkLoaded);

        // 设置10秒超时
        setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(checkLoaded);
            resolve();
        }, 10000);
    });
}

/**
 * 在指定标签页中执行数据提取脚本
 * @param {number} tabId 标签页ID
 * @returns {Promise<Object|null>} 提取的数据或null
 */
async function executeDataExtractionScript(tabId) {
    try {
        const result = await chrome.scripting.executeScript({
            target: {tabId}, function: extractDataFromPage, args: [USER_INFO_KEYS]
        });

        if (result && result[0] && result[0].result) {
            logWithTimestamp('info', '成功从标签页获取用户数据');
            return result[0].result;
        }

        return null;
    } catch (error) {
        logWithTimestamp('error', '执行数据提取脚本失败', error.message);
        return null;
    }
}

/**
 * 从页面中提取数据的函数（在目标页面中执行）
 * @param {Array} userInfoKeys 用户信息键名数组
 * @returns {Object} 提取的数据
 */
function extractDataFromPage(userInfoKeys) {
    const foundData = {};

    for (const key of userInfoKeys) {
        const value = localStorage.getItem(key);
        if (value) {
            try {
                foundData[key] = JSON.parse(value);
            } catch (e) {
                foundData[key] = value;
            }
        }
    }

    return foundData;
}

/**
 * 从插件存储中获取数据
 * @param {string} key 存储键
 * @returns {Promise<any>} 存储的数据
 */
async function getFromPluginStorage(key) {
    try {
        const result = await chrome.storage.local.get([key]);
        return result[key] || null;
    } catch (error) {
        logWithTimestamp('error', `从插件存储获取数据失败: ${key}`, error.message);
        return null;
    }
}

/**
 * 缓存数据到插件存储
 * @param {Object} data 要缓存的数据
 * @returns {Promise<boolean>} 是否成功
 */
async function cacheDataToPlugin(data) {
    if (!data) return false;

    try {
        await chrome.storage.local.set({
            [STORAGE_KEYS.BBS_CACHE_DATA]: data, [STORAGE_KEYS.LAST_UPDATED]: new Date().toISOString()
        });
        logWithTimestamp('info', '已将网页数据完整缓存到插件中');
        return true;
    } catch (error) {
        logWithTimestamp('error', '缓存数据到插件失败', error.message);
        return false;
    }
}

/**
 * 保存用户数据到本地存储
 * @param {Object} userData 用户数据
 * @returns {Promise<boolean>} 是否保存成功
 */
export async function saveUserData(userData) {
    if (!userData) {
        logWithTimestamp('warn', '尝试保存空的用户数据');
        return false;
    }

    try {
        await chrome.storage.local.set({
            [STORAGE_KEYS.USER_DATA]: userData, [STORAGE_KEYS.USER_DATA_SOURCE]: {
                website: TARGET_WEBSITE_URL, timestamp: new Date().toISOString()
            }
        });
        logWithTimestamp('info', '已保存用户数据');
        return true;
    } catch (error) {
        logWithTimestamp('error', '保存用户数据失败', error.message);
        return false;
    }
}

/**
 * 检查用户是否已登录
 * @returns {Promise<boolean>} 是否已登录
 */
export async function isUserLoggedIn() {
    try {
        const cacheData = await getCacheData();

        if (!cacheData || !cacheData.userData) {
            return false;
        }

        return validateUserData(cacheData.userData);
    } catch (error) {
        logWithTimestamp('error', '检查用户登录状态失败', error.message);
        return false;
    }
}

/**
 * 打开登录页面
 * @returns {Promise<Object>} 创建的标签页对象
 */
export async function openLoginPage() {
    try {
        const loginUrl = `${TARGET_WEBSITE_URL}?source=extension&action=login`;
        const tab = await chrome.tabs.create({url: loginUrl, active: true});
        logWithTimestamp('info', '已打开登录页面');
        return tab;
    } catch (error) {
        logWithTimestamp('error', '打开登录页面失败', error.message);
        throw error;
    }
}

/**
 * 清理缓存数据
 * @returns {Promise<boolean>} 是否清理成功
 */
export async function clearUserCache() {
    try {
        const keysToRemove = [STORAGE_KEYS.BBS_CACHE_DATA, STORAGE_KEYS.USER_DATA, STORAGE_KEYS.DEVICE_ID, STORAGE_KEYS.LAST_UPDATED, STORAGE_KEYS.USER_DATA_SOURCE, STORAGE_KEYS.LAST_SYNCED_BOOKMARKS];

        await chrome.storage.local.remove(keysToRemove);
        logWithTimestamp('info', '已清理用户缓存数据');
        return true;
    } catch (error) {
        logWithTimestamp('error', '清理用户缓存数据失败', error.message);
        return false;
    }
}

/**
 * 获取用户数据的摘要信息
 * @returns {Promise<Object>} 用户数据摘要
 */
export async function getUserDataSummary() {
    try {
        const cacheData = await getCacheData();

        if (!cacheData) {
            return buildResponse(false, null, '无用户数据');
        }

        const summary = {
            hasUserData: !!cacheData.userData,
            hasDeviceId: !!cacheData.deviceId,
            isLoggedIn: await isUserLoggedIn(),
            dataKeys: Object.keys(cacheData),
            lastUpdated: await getFromPluginStorage(STORAGE_KEYS.LAST_UPDATED)
        };

        return buildResponse(true, summary);
    } catch (error) {
        logWithTimestamp('error', '获取用户数据摘要失败', error.message);
        return buildResponse(false, null, error.message);
    }
}