/**
 * 工具函数库
 * 提供通用的工具函数，提高代码复用性
 */

import {REQUEST_CONFIG, RESPONSE_CODES} from './config.js';

/**
 * 获取浏览器名称
 * @returns {string} 浏览器名称
 */
export function getBrowserName() {
    const userAgent = navigator.userAgent;
    if (userAgent.includes("Chrome")) {
        return "Chrome";
    } else if (userAgent.includes("Firefox")) {
        return "Firefox";
    } else if (userAgent.includes("Safari")) {
        return "Safari";
    } else if (userAgent.includes("Edge")) {
        return "Edge";
    } else {
        return "Unknown Browser";
    }
}

/**
 * 格式化日期为 yyyy-MM-dd HH:mm:ss
 * @param {Date} date 要格式化的日期
 * @returns {string} 格式化后的日期字符串
 */
export function formatDate(date) {
    const pad = (n) => (n < 10 ? '0' + n : n);
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` + `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

/**
 * 延迟执行函数
 * @param {number} ms 延迟毫秒数
 * @returns {Promise} Promise对象
 */
export function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 带重试的异步函数执行器
 * @param {Function} fn 要执行的异步函数
 * @param {number} retryCount 重试次数
 * @param {number} retryDelay 重试延迟（毫秒）
 * @returns {Promise} 执行结果
 */
export async function withRetry(fn, retryCount = REQUEST_CONFIG.RETRY_COUNT, retryDelay = REQUEST_CONFIG.RETRY_DELAY) {
    let lastError;

    for (let i = 0; i <= retryCount; i++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;
            if (i < retryCount) {
                console.warn(`第${i + 1}次尝试失败，${retryDelay}ms后重试:`, error.message);
                await delay(retryDelay);
            }
        }
    }

    throw lastError;
}

/**
 * 安全的 JSON 解析
 * @param {string} jsonString JSON字符串
 * @param {any} defaultValue 解析失败时的默认值
 * @returns {any} 解析结果或默认值
 */
export function safeJsonParse(jsonString, defaultValue = null) {
    try {
        return JSON.parse(jsonString);
    } catch (error) {
        console.warn('JSON解析失败:', error.message);
        return defaultValue;
    }
}

/**
 * 深度克隆对象
 * @param {any} obj 要克隆的对象
 * @returns {any} 克隆后的对象
 */
export function deepClone(obj) {
    if (obj === null || typeof obj !== "object") {
        return obj;
    }

    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }

    if (obj instanceof Array) {
        return obj.map(item => deepClone(item));
    }

    if (typeof obj === "object") {
        const clonedObj = {};
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                clonedObj[key] = deepClone(obj[key]);
            }
        }
        return clonedObj;
    }
}

/**
 * 检查对象是否为空
 * @param {any} obj 要检查的对象
 * @returns {boolean} 是否为空
 */
export function isEmpty(obj) {
    if (obj === null || obj === undefined) {
        return true;
    }

    if (typeof obj === 'string' || Array.isArray(obj)) {
        return obj.length === 0;
    }

    if (typeof obj === 'object') {
        return Object.keys(obj).length === 0;
    }

    return false;
}

/**
 * 截断字符串
 * @param {string} str 原字符串
 * @param {number} maxLength 最大长度
 * @param {string} suffix 后缀
 * @returns {string} 截断后的字符串
 */
export function truncateString(str, maxLength, suffix = '...') {
    if (!str || str.length <= maxLength) {
        return str;
    }
    return str.substring(0, maxLength - suffix.length) + suffix;
}

/**
 * 验证用户数据的有效性
 * @param {any} userData 用户数据
 * @returns {boolean} 是否有效
 */
export function validateUserData(userData) {
    if (!userData || typeof userData !== 'object') {
        return false;
    }

    // 检查是否有访问令牌
    const hasToken = userData.accessToken || userData.token;
    if (!hasToken) {
        return false;
    }

    return true;
}

/**
 * 验证 API 响应
 * @param {any} response API响应
 * @returns {Object} 验证结果 {isValid: boolean, isSuccess: boolean, isAuthExpired: boolean}
 */
export function validateApiResponse(response) {
    const result = {
        isValid: false, isSuccess: false, isAuthExpired: false
    };

    if (!response || typeof response !== 'object') {
        return result;
    }

    result.isValid = true;
    result.isSuccess = response.code === RESPONSE_CODES.SUCCESS;
    result.isAuthExpired = response.code === RESPONSE_CODES.AUTH_EXPIRED;

    return result;
}

/**
 * 构建标准化的响应对象
 * @param {boolean} success 是否成功
 * @param {any} data 数据
 * @param {string} error 错误信息
 * @param {Object} meta 元数据
 * @returns {Object} 标准响应对象
 */
export function buildResponse(success, data = null, error = null, meta = {}) {
    return {
        success, data, error, timestamp: new Date().toISOString(), ...meta
    };
}

/**
 * 记录操作日志（带时间戳）
 * @param {string} level 日志级别 (info, warn, error)
 * @param {string} message 日志信息
 * @param {any} data 附加数据
 */
export function logWithTimestamp(level, message, data = null) {
    const timestamp = formatDate(new Date());
    const logMessage = `[${timestamp}] ${message}`;

    switch (level) {
        case 'info':
            console.log(logMessage, data || '');
            break;
        case 'warn':
            console.warn(logMessage, data || '');
            break;
        case 'error':
            console.error(logMessage, data || '');
            break;
        default:
            console.log(logMessage, data || '');
    }
} 