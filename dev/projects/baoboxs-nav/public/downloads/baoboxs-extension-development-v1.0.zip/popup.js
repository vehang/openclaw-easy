// 导入全局配置
import {TARGET_WEBSITE_URL} from './config.js';

// 导入用户数据服务
import {getCacheData, isUserLoggedIn, openLoginPage, saveUserData} from './userDataService.js';

// 全局变量
let bookmarksData = [];
let userData = null;

console.log('popup.js 文件已加载');

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
    console.log('DOM内容已加载完成');

    try {
        // 初始化UI元素引用
        initUIElements();

        // 并行加载用户数据和收藏夹数据
        await Promise.all([loadUserData().catch(err => console.error('加载用户数据出错:', err)), loadBookmarks().catch(err => console.error('加载收藏夹出错:', err))]);

        // 设置事件监听器
        setupEventListeners();
    } catch (error) {
        console.error('初始化过程中发生错误:', error);
    }
});

// 初始化UI元素引用
function initUIElements() {
    window.userNotLoggedInElement = document.querySelector('.user-not-logged-in');
    window.userLoggedInElement = document.querySelector('.user-logged-in');
    window.userAvatarElement = document.getElementById('userAvatar');
    window.userNameElement = document.getElementById('userName');
    window.lastSyncTimeElement = document.getElementById('lastSyncTime');
    window.loginButton = document.getElementById('loginButton');
    window.bookmarksContainer = document.getElementById('bookmarks');
    window.syncButton = document.getElementById('syncButton');
    window.statusMessage = document.getElementById('statusMessage');
}

// 设置事件监听器
function setupEventListeners() {
    if (window.loginButton) {
        window.loginButton.addEventListener('click', async () => {
            await openLoginPage();
        });
    }

    if (window.syncButton) {
        window.syncButton.addEventListener('click', async () => {
            await syncDataToServer();
        });
    }

    if (window.bookmarksContainer) {
        window.bookmarksContainer.addEventListener('click', (event) => {
            const toggleElement = event.target.closest('.folder-toggle');
            if (toggleElement) {
                const targetId = toggleElement.dataset.targetId;
                const childrenContainer = document.getElementById(targetId);
                const iconElement = toggleElement.querySelector('.folder-icon');

                if (childrenContainer) {
                    const isHidden = childrenContainer.classList.toggle('hidden');
                    if (iconElement) {
                        iconElement.textContent = isHidden ? '📁' : '📂';
                    }
                }
            }
        });
    }
}

// 加载用户数据
async function loadUserData() {
    try {
        const isLoggedIn = await isUserLoggedIn();
        if (isLoggedIn) {
            const cacheData = await getCacheData();
            if (cacheData && cacheData.userData) {
                updateUserInfoUI(cacheData.userData);
            } else {
                showUserNotLoggedIn();
            }
        } else {
            showUserNotLoggedIn();
        }
    } catch (error) {
        console.error('加载用户数据失败:', error);
        showUserNotLoggedIn();
        showStatusMessage('加载用户数据失败: ' + error.message, 'error');
    }
}

// 更新用户信息UI
function updateUserInfoUI(userData) {
    if (window.userNotLoggedInElement && window.userLoggedInElement) {
        window.userNotLoggedInElement.classList.add('hidden');
        window.userLoggedInElement.classList.remove('hidden');
    }

    if (window.userAvatarElement) {
        if (userData.avatar || userData.avatarUrl) {
            window.userAvatarElement.src = userData.avatar || userData.avatarUrl;
            window.userAvatarElement.onload = function () {
                this.style.width = '50px';
                this.style.height = '50px';
                this.style.borderRadius = '50%';
                this.style.objectFit = 'cover';
            };
            window.userAvatarElement.onerror = function () {
                this.src = 'images/def_user_icon1.png';
            };
        } else {
            window.userAvatarElement.src = 'images/def_user_icon1.png';
        }
    }

    if (window.userNameElement) {
        window.userNameElement.textContent = userData.nickname || userData.username || userData.name || '用户';
    }

    if (window.lastSyncTimeElement) {
        const lastSyncTime = localStorage.getItem('lastSyncTime');
        window.lastSyncTimeElement.textContent = lastSyncTime ? '上次同步: ' + new Date(lastSyncTime).toLocaleString() : '未同步';
    }
}

// 显示用户未登录状态
function showUserNotLoggedIn() {
    if (window.userLoggedInElement && window.userNotLoggedInElement) {
        window.userLoggedInElement.classList.add('hidden');
        window.userNotLoggedInElement.classList.remove('hidden');
    }
}

// 加载收藏夹数据
async function loadBookmarks() {
    try {
        const bookmarks = await chrome.bookmarks.getTree();
        bookmarksData = bookmarks;
        displayBookmarks(bookmarks);
    } catch (error) {
        console.error('加载收藏夹失败:', error);
        if (window.bookmarksContainer) {
            window.bookmarksContainer.innerHTML = '<p>加载收藏夹失败</p>';
        }
        showStatusMessage('加载收藏夹失败: ' + error.message, 'error');
    }
}

// 显示收藏夹数据
function displayBookmarks(bookmarks) {
    if (!window.bookmarksContainer) return;

    if (!bookmarks || bookmarks.length === 0 || !bookmarks[0].children || bookmarks[0].children.length === 0) {
        window.bookmarksContainer.innerHTML = '<p>没有收藏夹数据</p>';
        return;
    }

    const bookmarksHtml = formatBookmarksTree(bookmarks[0].children);
    window.bookmarksContainer.innerHTML = bookmarksHtml;
}

// 辅助函数：递归格式化书签树为HTML
function formatBookmarksTree(bookmarksTree, level = 0) {
    let html = '';
    for (const node of bookmarksTree) {
        if (level === 0 && !node.children && !node.url) continue;

        if (node.children && node.children.length > 0) {
            const childrenId = `folder-children-${node.id}`;
            html += `<div class="folder-node" style="margin-left: ${level + 15}px;">`;
            html += `<span class="folder-toggle" data-target-id="${childrenId}" style="cursor: pointer; display: inline-flex; align-items: center;">`;
            html += `<span class="folder-icon" style="margin-right: 4px;">📂</span><strong>${node.title || '未命名文件夹'}</strong>`;
            html += `</span>`;
            // 移除 hidden 类以默认展开文件夹
            html += `<div id="${childrenId}" class="folder-children">`;
            html += formatBookmarksTree(node.children, level + 1);
            html += `</div>`;
            html += `</div>`;
        } else if (node.url) {
            const displayUrl = node.url.length > 40 ? node.url.substring(0, 37) + '...' : node.url;
            html += `<div style="margin-left: ${level + 15}px; display: flex; align-items: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px; margin-bottom: 2px;">`;
            html += `<a href="${node.url}" target="_blank" style="color: #1a0dab; text-decoration: none;" title="${node.title}\n${node.url}">${node.title || '未命名书签'}</a>`;
            html += `</div>`;
        }
    }
    return html;
}

// 同步数据到服务器
async function syncDataToServer() {
    try {
        if (window.syncButton) {
            window.syncButton.disabled = true;
        }
        showStatusMessage('正在同步数据...', 'info');

        const isLoggedIn = await isUserLoggedIn();
        if (!isLoggedIn) {
            showStatusMessage('请先登录后再同步数据', 'error');
            if (window.syncButton) {
                window.syncButton.disabled = false;
            }
            return;
        }

        const result = await chrome.runtime.sendMessage({action: 'syncData'});
        if (result && result.success) {
            const {code, errorMsg} = result.data || {};

            if (code === 0) {
                const now = new Date().toISOString();
                localStorage.setItem('lastSyncTime', now);
                if (window.lastSyncTimeElement) {
                    window.lastSyncTimeElement.textContent = '上次同步: ' + new Date(now).toLocaleString();
                }
                showStatusMessage('数据同步成功!', 'success');
            } else if (code === 9996) {
                showStatusMessage('登录失效，请重新登录', 'error');
                const loginUrl = `${TARGET_WEBSITE_URL}?source=extension&action=forceLogin`;

                // 查找并关闭已打开的相关网页
                const tabs = await chrome.tabs.query({url: `${TARGET_WEBSITE_URL}/*`});
                const tabIds = tabs.map(tab => tab.id);
                if (tabIds.length > 0) {
                    await chrome.tabs.remove(tabIds);
                }

                // 重新打开登录页面
                await chrome.tabs.create({url: loginUrl, active: true});
            } else {
                showStatusMessage('同步失败: ' + (errorMsg || '未知错误'), 'error');
                //showStatusMessage('同步失败3: ' + result.data.code, 'error');
            }
        } else {
            if (result && result.data) {
                const {code, errorMsg} = result.data || {};
                showStatusMessage('同步失败: ' + errorMsg ? errorMsg : '未知错误', 'error');
            } else {
                const errorMsg = result && result.error ? result.error : '未知错误';
                showStatusMessage('同步失败: ' + errorMsg, 'error');
            }

        }
    } catch (error) {
        console.error('同步数据失败:', error);
        showStatusMessage('同步数据失败: ' + error.message, 'error');
    } finally {
        if (window.syncButton) {
            window.syncButton.disabled = false;
        }
    }
}

// 显示状态消息
function showStatusMessage(message, type = 'info') {
    if (!window.statusMessage) return;

    window.statusMessage.textContent = message;
    window.statusMessage.className = `status ${type}`;
    window.statusMessage.classList.remove('hidden');

    if (type === 'success' || type === 'info') {
        setTimeout(() => {
            window.statusMessage.classList.add('hidden');
        }, 3000);
    }
}