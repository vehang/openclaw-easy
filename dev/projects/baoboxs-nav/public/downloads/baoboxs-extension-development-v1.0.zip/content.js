/**
 * 内容脚本 - 从网页中提取数据并提供页面功能
 * 此脚本会注入到匹配的网页中运行，负责数据提取和页面增强
 */

// 直接定义配置常量，避免ES模块导入问题
const USER_INFO_KEYS = [
  'userData',
  'baoboxs_userData',
  'deviceId',
  'baoboxs_deviceId',
  'userInfo',
  'user',
  'token',
  'accessToken',
  'baoboxs_attr1',
  'baoboxs_attr2',
  'baoboxs_attr3',
  'baoboxs_attr4',
  'baoboxs_attr5'
];

const DEVICE_ID_KEYS = [
  'deviceId',
  'device_id',
  'device-id',
  'baoboxDeviceId',
  'userDeviceId',
  'clientId',
  'client_id'
];

/**
 * 从localStorage中提取设备ID和用户数据
 * @returns {Object} 提取的数据对象 {deviceId, userData}
 */
function extractDataFromLocalStorage() {
  const data = {
    deviceId: null,
    userData: null
  };
  
  console.log('[数据提取] 开始从localStorage提取数据...');
  console.log('[数据提取] 当前域名:', window.location.hostname);
  
  // 先打印所有localStorage键值，用于调试
  console.log('[数据提取] localStorage中的所有键名:');
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    console.log(`  - ${key}: ${localStorage.getItem(key)?.substring(0, 100)}...`);
  }
  
  // 尝试查找设备ID
  console.log('[数据提取] 查找设备ID，搜索键名:', DEVICE_ID_KEYS);
  for (const key of DEVICE_ID_KEYS) {
    const value = localStorage.getItem(key);
    if (value) {
      data.deviceId = { key, value };
      console.log(`[数据提取] ✓ 找到设备ID: ${key} = ${value}`);
      break;
    }
  }
  
  if (!data.deviceId) {
    console.log('[数据提取] ✗ 未找到任何设备ID');
  }
  
  // 尝试查找用户数据
  console.log('[数据提取] 查找用户数据，搜索键名:', USER_INFO_KEYS);
  for (const key of USER_INFO_KEYS) {
    const value = localStorage.getItem(key);
    if (value) {
      try {
        // 尝试解析JSON格式的用户数据
        const parsedValue = JSON.parse(value);
        data.userData = { key, value: parsedValue };
        console.log(`[数据提取] ✓ 找到用户数据(JSON): ${key}`, parsedValue);
        break;
      } catch (e) {
        // 如果不是JSON格式，仍然保存原始值
        data.userData = { key, value };
        console.log(`[数据提取] ✓ 找到用户数据(字符串): ${key} = ${value}`);
        break;
      }
    }
  }
  
  if (!data.userData) {
    console.log('[数据提取] ✗ 未找到任何用户数据');
    // 尝试搜索任何包含 'user' 或 'token' 的键名
    console.log('[数据提取] 尝试模糊搜索包含用户相关关键词的键名...');
    const searchKeywords = ['user', 'token', 'auth', 'login', 'account', 'baobox'];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      const lowerKey = key.toLowerCase();
      for (const keyword of searchKeywords) {
        if (lowerKey.includes(keyword)) {
          const value = localStorage.getItem(key);
          console.log(`[数据提取] 发现可能的用户数据: ${key} = ${value?.substring(0, 200)}...`);
        }
      }
    }
  }
  
  console.log('[数据提取] 提取结果:', data);
  return data;
}

/**
 * 将数据发送到扩展
 * @param {Object} data 要发送的数据
 * @returns {Promise<boolean>} 是否发送成功
 */
function sendDataToExtension(data) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({
        action: 'storeWebsiteData',
        data
      }, response => {
        if (chrome.runtime.lastError) {
          console.error('[数据发送] 发送消息到扩展失败:', chrome.runtime.lastError.message);
          resolve(false);
          return;
        }
        
        if (response && response.success) {
          console.log('[数据发送] 数据已成功发送到扩展');
          resolve(true);
        } else {
          console.error('[数据发送] 发送数据到扩展失败:', response?.error || '未知错误');
          resolve(false);
        }
      });
    } catch (error) {
      console.error('[数据发送] 发送数据到扩展时出错:', error.message);
      resolve(false);
    }
  });
}

/**
 * 初始化数据提取功能
 * @returns {void}
 */
function initializeDataExtraction() {
  console.log('[初始化] 开始初始化数据提取功能');
  
  // 从localStorage提取数据
  const data = extractDataFromLocalStorage();
  
  // 如果找到了任何数据，发送到扩展
  if (data.deviceId || data.userData) {
    console.log('[初始化] 找到数据，发送到扩展');
    sendDataToExtension(data);
  } else {
    console.log('[初始化] 未找到相关数据');
  }
  
  // 设置监听器，当localStorage变化时重新提取
  window.addEventListener('storage', (event) => {
    console.log('[存储监听] localStorage发生变化:', event.key);
    
    // 检查是否是我们关心的键
    if (
      DEVICE_ID_KEYS.includes(event.key) || 
      USER_INFO_KEYS.includes(event.key)
    ) {
      console.log('[存储监听] 检测到相关数据变化，重新提取');
      const updatedData = extractDataFromLocalStorage();
      sendDataToExtension(updatedData);
    }
  });
}

/**
 * 主函数：初始化所有功能
 * @returns {void}
 */
function main() {
  console.log('[主函数] 内容脚本开始执行');
  
  try {
    // 初始化数据提取功能
    initializeDataExtraction();
    console.log('[主函数] 内容脚本初始化完成');
  } catch (error) {
    console.error('[主函数] 内容脚本初始化失败:', error.message);
  }
}

/**
 * 监听来自扩展的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[消息监听] 收到来自扩展的消息:', message.action);
  
  if (message.action === 'getLocalStorageData') {
    try {
      const data = extractDataFromLocalStorage();
      console.log('[消息监听] 返回localStorage数据');
      sendResponse(data);
    } catch (error) {
      console.error('[消息监听] 获取localStorage数据失败:', error.message);
      sendResponse(null);
    }
    return true;
  }
  
  console.warn('[消息监听] 未知的消息类型:', message.action);
  return false;
});

// 页面加载完成后执行主函数
if (document.readyState === 'complete') {
  main();
} else {
  window.addEventListener('load', main);
}