// 开发环境配置
window.ENV = 'development'; 