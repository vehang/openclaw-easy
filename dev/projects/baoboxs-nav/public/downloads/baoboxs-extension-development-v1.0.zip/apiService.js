/**
 * API 服务
 * 统一管理所有 API 请求，提供重试、错误处理等功能
 */

import {
    API_BASE_URL, API_ENDPOINTS, REQUEST_CONFIG, RESPONSE_CODES, UPLOAD_BOOKMARKS_API_URL, COLL_BOOKMARK_API_URL
} from './config.js';
import {
    withRetry, validateApiResponse, buildResponse, logWithTimestamp, getBrowserName
} from './utils.js';
import {getCacheData, clearUserCache, openLoginPage} from './userDataService.js';

/**
 * 基础 API 请求函数
 * @param {string} url API 地址
 * @param {Object} data 请求数据
 * @param {Object} options 请求选项
 * @returns {Promise<Object>} 请求结果
 */
async function makeRequest(url, data = {}, options = {}) {
    const {
        method = 'POST', timeout = REQUEST_CONFIG.TIMEOUT, requireAuth = true, ...otherOptions
    } = options;

    try {
        // 如果需要认证，获取用户数据
        let headers = {
            'Content-Type': 'application/json', ...otherOptions.headers
        };

        if (requireAuth) {
            const cacheData = await getCacheData();

            if (!cacheData || !cacheData.userData) {
                await openLoginPage();
                return buildResponse(false, null, '请先登录后再操作', {needLogin: true});
            }

            // 添加认证头
            const token = cacheData.userData.accessToken || cacheData.userData.token || '';
            headers['Authorization'] = `Bearer ${token}`;
        }

        // 发送请求
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);

        const response = await fetch(url, {
            method, headers, body: JSON.stringify(data), signal: controller.signal, ...otherOptions
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const result = await response.json();
        return handleApiResponse(result);
    } catch (error) {
        logWithTimestamp('error', `API请求失败: ${url}`, error.message);

        if (error.name === 'AbortError') {
            return buildResponse(false, null, '请求超时');
        }

        return buildResponse(false, null, error.message);
    }
}

/**
 * 处理 API 响应
 * @param {Object} response API 响应
 * @returns {Promise<Object>} 处理后的响应
 */
async function handleApiResponse(response) {
    const validation = validateApiResponse(response);

    if (!validation.isValid) {
        return buildResponse(false, null, '无效的API响应');
    }

    if (validation.isSuccess) {
        return buildResponse(true, response);
    }

    if (validation.isAuthExpired) {
        // 认证过期，清理缓存并打开登录页面
        await clearUserCache();
        await openLoginPage();
        return buildResponse(false, null, '登录已失效，请重新登录', {needLogin: true});
    }

    return buildResponse(false, null, response.errorMsg || '操作失败');
}

/**
 * 带重试的 API 请求
 * @param {string} url API 地址
 * @param {Object} data 请求数据
 * @param {Object} options 请求选项
 * @returns {Promise<Object>} 请求结果
 */
export async function apiRequestWithRetry(url, data = {}, options = {}) {
    return withRetry(() => makeRequest(url, data, options), options.retryCount || REQUEST_CONFIG.RETRY_COUNT, options.retryDelay || REQUEST_CONFIG.RETRY_DELAY);
}

/**
 * 上传书签数据到服务器
 * @param {Object} bookmarksData 书签数据
 * @returns {Promise<Object>} 上传结果
 */
export async function uploadBookmarks(bookmarksData) {
    logWithTimestamp('info', '开始上传书签数据');

    try {
        const cacheData = await getCacheData();

        const requestData = {
            bookmarks: bookmarksData.bookmarks,
            userData: cacheData.userData,
            deviceId: cacheData.deviceId,
            timestamp: bookmarksData.timestamp,
            browserName: getBrowserName()
        };

        return await apiRequestWithRetry(UPLOAD_BOOKMARKS_API_URL, requestData);
    } catch (error) {
        logWithTimestamp('error', '上传书签数据失败', error.message);
        return buildResponse(false, null, error.message);
    }
}

/**
 * 添加单个书签
 * @param {Object} bookmarkInfo 书签信息
 * @returns {Promise<Object>} 添加结果
 */
export async function addBookmark(bookmarkInfo) {
    logWithTimestamp('info', '开始添加书签', bookmarkInfo.title);

    try {
        const cacheData = await getCacheData();

        const requestData = {
            bookmark: {
                url: bookmarkInfo.url,
                title: bookmarkInfo.title,
                favicon: bookmarkInfo.favicon,
                addTime: bookmarkInfo.timestamp,
                description: bookmarkInfo.description || '',
                keywords: bookmarkInfo.keywords || ''
            }, deviceId: cacheData.deviceId, userData: cacheData.userData, browserName: getBrowserName()
        };

        return await apiRequestWithRetry(COLL_BOOKMARK_API_URL, requestData);
    } catch (error) {
        logWithTimestamp('error', '添加书签失败', error.message);
        return buildResponse(false, null, error.message);
    }
}

/**
 * 检查 API 服务状态
 * @returns {Promise<Object>} 服务状态
 */
export async function checkApiStatus() {
    try {
        const statusUrl = `${API_BASE_URL}/api/status`;
        const result = await makeRequest(statusUrl, {}, {
            method: 'GET', requireAuth: false, timeout: 5000, retryCount: 1
        });

        return result;
    } catch (error) {
        logWithTimestamp('error', '检查API状态失败', error.message);
        return buildResponse(false, null, '无法连接到服务器');
    }
}

/**
 * 批量操作的通用处理器
 * @param {Array} items 要处理的项目列表
 * @param {Function} processor 处理函数
 * @param {Object} options 选项
 * @returns {Promise<Object>} 批量处理结果
 */
export async function batchProcess(items, processor, options = {}) {
    const {
        batchSize = 10, delay = 100, continueOnError = true
    } = options;

    const results = [];
    const errors = [];

    for (let i = 0; i < items.length; i += batchSize) {
        const batch = items.slice(i, i + batchSize);

        const batchPromises = batch.map(async (item, index) => {
            try {
                const result = await processor(item);
                return {index: i + index, success: true, result};
            } catch (error) {
                const errorInfo = {index: i + index, success: false, error: error.message};
                if (!continueOnError) {
                    throw error;
                }
                return errorInfo;
            }
        });

        const batchResults = await Promise.all(batchPromises);

        batchResults.forEach(result => {
            if (result.success) {
                results.push(result);
            } else {
                errors.push(result);
            }
        });

        // 批次间延迟
        if (i + batchSize < items.length && delay > 0) {
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }

    return buildResponse(errors.length === 0, {
        results, errors
    }, errors.length > 0 ? `${errors.length} 个操作失败` : null, {
        total: items.length, success: results.length, failed: errors.length
    });
} 